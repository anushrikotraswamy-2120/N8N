# AARYA — n8n Agentic Workflows (51 agents)

One import-ready n8n workflow per agent in the AARYA catalogue. Each follows the
agentic pattern:

```
Trigger → AI Agent ( OpenRouter model + Window memory + tools ) → Output
```

- **LLM provider:** OpenRouter — node `@n8n/n8n-nodes-langchain.lmChatOpenRouter`,
  model `anthropic/claude-3.5-sonnet` (change in `generate.py` → `OPENROUTER_MODEL`).
- **Agent node:** `@n8n/n8n-nodes-langchain.agent` (tool-calling), with a use-case
  system prompt and `Window Buffer Memory`.
- **Tools:** `toolHttpRequest` nodes pointed at the relevant Axian BSS/OSS/CRM/security
  systems, plus a `Calculator` tool on numeric agents. Tools the model can parameterise
  use `placeholderDefinitions`; write/action tools are **GATED** (POST) and send a
  `$fromAI('payload', …, 'json')` body so the model must construct the action explicitly.
- **Triggers chosen per use case:** Chat Trigger for live/conversational agents,
  Schedule Trigger for continuous scoring/monitoring/batch agents, Webhook for
  event-driven (order-creation / onboarding) agents.

## Before you run
1. Import a `.json` into n8n (Workflows → Import from File).
2. Create an **OpenRouter** credential and select it on the *OpenRouter Chat Model* node
   (the placeholder id `REPLACE_OPENROUTER_CRED` won't resolve until you do).
3. Replace the placeholder base URL `https://api.axian.internal/...` on the HTTP tools
   with your real endpoints, and attach auth credentials to those tool nodes.
4. Review every **GATED** tool — these perform irreversible actions (offers, payments,
   provisioning, dispatch, blocking). Add a human-approval (Send and Wait) step in
   production per the platform's safety guidance.

## Workflows

| Persona | Agent | Trigger | Tools | Tier/Day | File |
|---|---|---|---|---|---|
| AURA | CSR AI Assistant Agent | chat | 4 | T1/D1 | `aura_csr_ai_assistant_agent.json` |
| AURA | Churn Prediction & Retention Agent | schedule | 4 | T1/D1 | `aura_churn_prediction_retention_agent.json` |
| AURA | Website Personalisation Agent | webhook | 2 | T1/D1 | `aura_website_personalisation_agent.json` |
| AURA | Customer 360 Insight Agent | chat | 3 | T2/D1 | `aura_customer_360_insight_agent.json` |
| AURA | Next Best Offer (NBO) Agent | webhook | 3 | T2/D1 | `aura_next_best_offer_nbo_agent.json` |
| AURA | Guided Onboarding Agent | chat | 3 | T1/D1 | `aura_guided_onboarding_agent.json` |
| AURA | Loyalty Propensity Agent | schedule | 2 | T1/D2 | `aura_loyalty_propensity_agent.json` |
| AURA | Gamification Intelligence Agent | schedule | 2 | T1/D2 | `aura_gamification_intelligence_agent.json` |
| AURA | Liability Forecast Agent | schedule | 3 | T2/D2 | `aura_liability_forecast_agent.json` |
| AURA | Coalition Partner Agent | chat | 2 | T2/D2 | `aura_coalition_partner_agent.json` |
| AURA | Churn & Propensity Scoring Agent | schedule | 3 | T1/D2 | `aura_churn_propensity_scoring_agent.json` |
| AURA | NBA / Upsell Agent | webhook | 2 | T1/D2 | `aura_nba_upsell_agent.json` |
| AURA | Explainability & Bias Agent | webhook | 2 | T2/D2 | `aura_explainability_bias_agent.json` |
| SEVA | Self-Care Chatbot Agent | chat | 3 | T1/D1 | `seva_self_care_chatbot_agent.json` |
| SEVA | KYC Verification Agent | webhook | 3 | T1/D1 | `seva_kyc_verification_agent.json` |
| SEVA | Complaint Resolution Agent | webhook | 3 | T1/D1 | `seva_complaint_resolution_agent.json` |
| SEVA | Bill Explainer Agent | chat | 3 | T2/D1 | `seva_bill_explainer_agent.json` |
| SEVA | Partner Onboarding Agent | chat | 3 | T1/D1 | `seva_partner_onboarding_agent.json` |
| SEVA | POS Retail Assist Agent | chat | 3 | T2/D1 | `seva_pos_retail_assist_agent.json` |
| SEVA | Agent-Assist in Care | chat | 2 | T1/D2 | `seva_agent_assist_in_care.json` |
| SEVA | Dealer Onboarding Agent | chat | 3 | T2/D2 | `seva_dealer_onboarding_agent.json` |
| SEVA | Model Retraining Agent | schedule | 3 | T2/D2 | `seva_model_retraining_agent.json` |
| NOVA | Order Fallout & Jeopardy Agent | schedule | 3 | T1/D1 | `nova_order_fallout_jeopardy_agent.json` |
| NOVA | Revenue Leakage Detection Agent | schedule | 3 | T1/D1 | `nova_revenue_leakage_detection_agent.json` |
| NOVA | Collections & Dunning Agent | schedule | 2 | T1/D1 | `nova_collections_dunning_agent.json` |
| NOVA | Promotion Eligibility Agent | webhook | 2 | T2/D1 | `nova_promotion_eligibility_agent.json` |
| NOVA | Tariff Change Impact Agent | webhook | 3 | T2/D1 | `nova_tariff_change_impact_agent.json` |
| NOVA | Field Workforce Agent | schedule | 3 | T1/D1 | `nova_field_workforce_agent.json` |
| NOVA | Closed-Loop Assurance Agent | schedule | 2 | T1/D2 | `nova_closed_loop_assurance_agent.json` |
| NOVA | Jeopardy & SLA Agent | schedule | 3 | T1/D2 | `nova_jeopardy_sla_agent.json` |
| NOVA | Activation Workflow Agent | webhook | 3 | T2/D2 | `nova_activation_workflow_agent.json` |
| NOVA | Stock Anomaly Agent | schedule | 3 | T2/D2 | `nova_stock_anomaly_agent.json` |
| NOVA | Data Migration Validation Agent | webhook | 3 | T1/D2 | `nova_data_migration_validation_agent.json` |
| NOVA | Programme Governance Agent | schedule | 2 | T1/D2 | `nova_programme_governance_agent.json` |
| VEGA | CPQ Assistant Agent | chat | 4 | T1/D1 | `vega_cpq_assistant_agent.json` |
| VEGA | B2B Lead-to-Order Agent | chat | 3 | T1/D1 | `vega_b2b_lead_to_order_agent.json` |
| VEGA | B2B Customer Hierarchy Agent | chat | 2 | T2/D1 | `vega_b2b_customer_hierarchy_agent.json` |
| VEGA | Commission Calculation Agent | schedule | 4 | T1/D2 | `vega_commission_calculation_agent.json` |
| VEGA | Channel Performance Agent | schedule | 3 | T1/D2 | `vega_channel_performance_agent.json` |
| VEGA | Network GIS Coverage Agent | webhook | 2 | T2/D1 | `vega_network_gis_coverage_agent.json` |
| VEGA | BoQ & Commercials Agent | chat | 3 | T2/D2 | `vega_boq_commercials_agent.json` |
| VEGA | SLA Breach Prediction Agent | schedule | 3 | T1/D1 | `vega_sla_breach_prediction_agent.json` |
| AEGIS | Fraud Detection Agent | schedule | 2 | T1/D1 | `aegis_fraud_detection_agent.json` |
| AEGIS | TMF Compliance Agent | schedule | 2 | T1/D2 | `aegis_tmf_compliance_agent.json` |
| AEGIS | Zero-Trust Policy Agent | schedule | 2 | T1/D2 | `aegis_zero_trust_policy_agent.json` |
| AEGIS | NIST CSF Scoring Agent | schedule | 3 | T1/D2 | `aegis_nist_csf_scoring_agent.json` |
| AEGIS | Multi-OpCo Tenant Agent | schedule | 2 | T2/D2 | `aegis_multi_opco_tenant_agent.json` |
| AEGIS | GDPR & Data Residency Agent | schedule | 2 | T2/D2 | `aegis_gdpr_data_residency_agent.json` |
| AEGIS | RPO/RTO Simulation Agent | schedule | 3 | T2/D2 | `aegis_rpo_rto_simulation_agent.json` |
| AEGIS | IAM & Certificate Rotation Agent | schedule | 3 | T2/D2 | `aegis_iam_certificate_rotation_agent.json` |
| AEGIS | Infra Drift Detection Agent | schedule | 2 | T2/D2 | `aegis_infra_drift_detection_agent.json` |

*Generated by `generate.py` — re-run it to regenerate all workflows after editing the model, endpoints, or prompts.*
